import ipaddress, socket
ATTEMPTS = []
_c, _cx, _g = socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo
def _local(h):
    if h in ("localhost", "testserver", None, ""): return True
    try: return ipaddress.ip_address(h).is_loopback
    except Exception: return False
def _chk(a):
    if isinstance(a, tuple) and not _local(a[0]):
        ATTEMPTS.append(a); raise RuntimeError(f"NETBLOCK {a}")
def connect(self, a): _chk(a); return _c(self, a)
def connect_ex(self, a): _chk(a); return _cx(self, a)
def gai(h, *a, **k):
    if not _local(h): ATTEMPTS.append(h); raise RuntimeError(f"NETBLOCK dns {h}")
    return _g(h, *a, **k)
socket.socket.connect, socket.socket.connect_ex, socket.getaddrinfo = connect, connect_ex, gai
def pytest_terminal_summary(terminalreporter):
    terminalreporter.write_line(f"NETBLOCK non-loopback attempts: {len(ATTEMPTS)} {ATTEMPTS[:5]}")
