import re, subprocess, sys
from pathlib import Path
root = Path("<repo>")
files = subprocess.run(["git", "ls-files", "-co", "--exclude-standard", "-z", "*.md"], cwd=root, capture_output=True).stdout.decode().split("\0")
bad = total = 0
for f in filter(None, files):
    p = root / f
    if not p.is_file(): continue
    t = re.sub(r"```.*?```", "", p.read_text(encoding="utf-8", errors="replace"), flags=re.S)
    for m in re.finditer(r"\]\(([^)\s]+)\)", t):
        u = m.group(1)
        if re.match(r"[a-z]+:|#", u): continue
        total += 1
        if not (p.parent / u.split("#")[0]).exists():
            bad += 1; print("BROKEN", f, u)
print("relative links", total, "broken", bad)
