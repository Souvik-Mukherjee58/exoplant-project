import os
import re
import subprocess
import sys
from pathlib import Path

clone = Path(sys.argv[1])
assert "<scratch>" in str(clone)
B, C, R, K, D = ("scripts/build_jwst_labels_from_mast.py", "scripts/check_mast_cache.py", "scripts/review_labels.py", "scripts/check_mast_completeness.py", "scripts/check_data_integrity.py")
M = [
    ("A allow-list off", B, "    raise ValueError(\n        f\"Refusing {flag}", "    return resolved\n    raise ValueError(\n        f\"Refusing {flag}"),
    ("A temp containing repo trusted", B, " and not root.is_relative_to(t)", ""),
    ("A link followed at allowed place", B, 'if resolved == root.joinpath(*ALLOWED_REPO_PATHS[flag].split("/")):', 'if resolved == root.joinpath(*ALLOWED_REPO_PATHS[flag].split("/")).resolve():'),
    ("A cache links checked late", B, "            assert_plain_file_target(target)  # before any request, not only before the write", "            pass"),
    ("A hard links accepted", B, " or path.stat().st_nlink > 1", ""),
    ("A separate locations off", B, "if o == s or o.is_relative_to(c) or s.is_relative_to(c):", "if False:"),
    ("A parent-is-file off", B, "if target.parent.exists() and not target.parent.is_dir():", "if False:"),
    ("A write_raw_cache unchecked", B, '    assert_safe_output(cache_dir, "--cache-dir")\n    data_path', "    data_path"),
    ("A write_candidates unchecked", B, '    assert_plain_file_target(assert_safe_output(out_path, "--output"))\n', ""),
    ("B dry-run not offline", B, "offline = args.offline or args.dry_run", "offline = args.offline"),
    ("B dry-run writes", B, "    if args.dry_run:\n        print(\"[4/4]", "    if False:\n        print(\"[4/4]"),
    ("B force-refresh allowed", B, "if args.dry_run and args.force_refresh:", "if False:"),
    ("B old cache accepted", B, "missing = [c for c in needed if c not in ephem.columns]", "missing = []"),
    ("C zero known", B, "math.isfinite(best) and best > 0", "math.isfinite(best)"),
    ("C only t0 checked", B, '(("t0", sigma_t0), ("period", sigma_p))', '(("t0", sigma_t0),)'),
    ("C flag not in CSV", B, '    "uncertainty_status",\n    "time_system"', '    "time_system"'),
    ("C flag not shown", R, 'if r.get("uncertainty_status", "").startswith("missing"):', "if False:"),
    ("D system validated by default", B, "VALIDATED_TIME_SYSTEMS: frozenset[str] = frozenset()", 'VALIDATED_TIME_SYSTEMS: frozenset[str] = frozenset({"BJD-TDB"})'),
    ("D validation ignored", B, "    if system not in validated_systems:", "    if False:"),
    ("D margin added", B, "        tol = SIGMA_K * sigma\n", "        tol = SIGMA_K * sigma + 0.01\n"),
    ("E missing obs_id kept", B, "        if not obs_id:\n            stats[\"dropped_missing_obs_id\"]", "        if False:\n            stats[\"dropped_missing_obs_id\"]"),
    ("E conflicts ignored", B, "if row_sha256(first) != row_sha256(rec):", "if False:"),
    ("E position ignored", B, 'if k["position"] != "agree":', "if False:"),
    ("E any suffix accepted", B, "if key[-1] in index.letters.get(host, set()):", "if True:"),
    ("E other planet's name ignored", B, 'if k["suffix"] and k["suffix"] !=', 'if False and k["suffix"] !='),
    ("E planned kept", B, "float(level) < 0:", "float(level) < -99:"),
    ("E mixed references silent", B, "if all(refs) and refs[0] != refs[1]:", "if False:"),
    ("E cache hash dropped", B, '(provenance or {}).get("mast", "")', '""'),
    ("E completeness ignores missing", K, "oid not in have:", "False:"),
    ("E completeness errors pass", K, "            failures += 1\n            continue", "            continue"),
    ("F counts not compared", C, "if len(cached) != len(live):", "if False:"),
    ("F extra live ids ignored", C, 'for oid in sorted(set(ids["live MAST"]) - set(ids["cache"]) - {""}):', "for oid in []:"),
    ("F duplicates ignored", C, "if v and values.count(v) > 1", "if False"),
    ("F candidate hash ignored", C, 'if rec["mast_cache_sha256"] != cache_sha:', "if False:"),
    ("G unknown e treated as known", B, '        reasons.append("eccentricity_unknown")', '        reasons.append("x")'),
    ("G limit flag ignored", B, 'if ecc_lim not in ("0", "0.0"):', "if False:"),
    ("G e=0 not questioned", B, "            if ecc == 0:", "            if False:"),
    ("G invalid e accepted", B, "if ecc is None or not 0 <= ecc < 1:", "if False:"),
    ("G omega convention assumed", B, '        reasons.append("omega_convention_not_confirmed")', "        pass"),
    ("G omega 0 treated as missing", B, "    if omega is None:", "    if not omega:"),
    ("G mixed references ignored", B, 'if "" in refs or len(refs) > 1:', "if False:"),
    ("G time system ignored", B, "not in VALIDATED_TIME_SYSTEMS:\n        reasons", "not in {'BJD-TDB'}:\n        reasons"),
    ("G no_event produced", B, '        notes.append("eclipse_not_excluded")  # so never', '        status = "no_event_in_window"  # so never'),
    ("G pairs dropped", B, "            row = dict(base)  # no pair is dropped: no eclipse is excluded", '            if ev["transit_result"] == "no":\n                continue\n            row = dict(base)'),
    ("G internal hint written", B, '            row.pop("transit_result", None)\n', ""),
    ("G list filtered by status", R, 'if r.get("eclipse_status") != "excluded"]', 'if r.get("match_status") == "eclipse_in_window"]'),
    ("G one convention only", R, "+ 180.0) % 360.0", "+ 0.0) % 360.0"),
    ("P22 rejection ignored", D, "    if has_rejection_row(review_text, planet, program_id):\n        return False\n", ""),
    ("P22 summary silent", R, 'if d.get("decision", "").startswith("APPROVED") and has_rejection_row(', "if False and has_rejection_row("),
    ("DI note as reviewer", D, 'if "checked_by" in columns and not', 'if False and not'),
    ("DI verified only if true", D, 'if v_val not in ("false", "0", "no", "f", "n", ""):', 'if v_val in ("true", "1", "yes", "t"):'),
    ("DI missing column accepted", D, 'if "verified" not in (reader.fieldnames or []):', "if False:"),
    ("DI metadata not required", D, 'failures.append(f"Cache file without metadata: {data_file.name}")', "pass"),
    ("DI csv hash unchecked", D, 'ecsv_file = ecsv_file.with_suffix(".csv")', "pass"),
]
env = {**os.environ, "PYTHONDONTWRITEBYTECODE": "1"}
bad = []
for name, rel, a, b in M:
    f = clone / rel
    orig = f.read_bytes()
    s = orig.decode("utf-8")
    if s.count(a) < 1:
        print("NOT FOUND |", name, flush=True)
        bad.append(name)
        continue
    try:
        f.write_bytes(s.replace(a, b).encode("utf-8"))
        r = subprocess.run([sys.executable, "-m", "pytest", "-q", "-x", "-p", "no:cacheprovider", "-p", "netblock", "tests/test_mast_label_builder.py", "tests/test_review_labels.py", "tests/test_data_integrity.py"],
                           cwd=clone / "backend", capture_output=True, text=True, env=env, timeout=120)
    finally:
        f.write_bytes(orig)
    ok = r.returncode == 1
    if not ok:
        bad.append(name)
    first = re.search(r"^FAILED tests/\S+?::(\S+)", r.stdout, re.M)
    print(f"{'caught  ' if ok else 'SURVIVED'} | {name} | {first.group(1)[:64] if first else r.stdout.strip().splitlines()[-1]}", flush=True)
print("mutations:", len(M), "not caught:", len(bad), bad)
