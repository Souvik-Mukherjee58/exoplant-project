# Phase 2 repairs, one item at a time (r2)

Order: A, B, C, F, G, E, D. Nothing is applied. The combined draft in `../phase2-repair-2026-11-24/` is kept as history and **must not
be applied**: item A in it has a hole (below), and its wording about 600 s is not supported.

## Item A: write-path allow-list (ready for review, not run)

| File | Diff | Lines |
|:--|:--|:--|
| `scripts/build_jwst_labels_from_mast.py` | `A/A-1-…diff` | +69 −14 |
| `backend/tests/test_mast_label_builder.py` | `A/A-2-…diff` | +145 −0 |

**Behaviour**

- `--cache-dir`, `--output` and `--summary` each have one location in the repository; otherwise only the temp directory.
- All three are checked before anything is fetched. Any refusal is exit 2.
- The writers check again, immediately before writing.

**Changed since the combined draft**

- The draft compared against the *resolved* allowed location, so a link at `reports/.mast_cache` pointing to
  `backend/data/reference/` was accepted. It now compares without following links there.
- Hard links and file links are refused, also for the files inside the cache directory.

**Tests (57 cases, additions only):** 15 forbidden targets × 3 flags; one location per flag (4); defaults and temp allowed; separate and
correct kinds; writers check themselves; directory link at the allowed location; directory link in temp; hard links (3). All use a
fake repository root. No existing test changes.

**Known limits**

- Tests need pytest's temp directory inside the system temp directory (the default; not with a `--basetemp` elsewhere).
- If the checkout itself is inside the temp directory, sibling folders count as temp.
- A link swapped in between the check and the write is not detected.
- `--dry-run` behaviour is unchanged; that is item B.

**Plan, after approval of this diff**

1. You confirm that the disk is resolved.
2. In a scratch clone: the tests alone (they must fail), then with the source diff; full backend suite; break each safeguard once.
3. I show you the results. Only then, with your approval, apply to the working tree. A commit needs separate approval.

## Item D: the 600 s figure

Not a validated bound, and no longer described as one. Unsupported or missing time systems stay `ambiguous`. Before any figure is
used, someone other than the author must check the derivation and that it covers all of these:

| Contribution | In the 600 s sum? | Status |
|:--|:--|:--|
| Sun–Earth light travel, barycentre included | Yes, 514.0 s from an assumed 1.03 au | Not independently checked |
| TDB − UTC | Yes, 69.2 s | Assumes 37 leap seconds |
| JWST − Earth | Yes, 6.0 s from an assumed 1.8 million km | Not independently checked |
| MAST `t_min`/`t_max` time scale | No: UTC is assumed | Unknown |
| What each `pl_tranmid_systemref` value means | No: my own pattern | Values not seen |
| Mislabelled or mixed systems in the literature | No | Unknown |
| T0 and period from different papers | No | Noted on the row only |
| Rounding of T0 in the archive | No | Unknown |
| Transit-timing variations | No | Not modelled |
| Light travel across the orbit, for eclipses | No | About 2a/c: 50 s at 0.05 au, 500 s at 0.5 au |
| Eclipse offset for e ≤ 0.1 or unknown e | No | See below |
| Window start/end versus actual exposure | No | Unknown |

**New finding, by inspection (existing code, not introduced by the repairs):** orbits with e ≤ 0.1, or with no eccentricity in the
archive, are treated as circular. The eclipse can be off by up to (2/π)·e·P: for e = 0.1 and P = 3 d that is about 4.6 h, far more
than any margin discussed here. So `eclipse_in_window`, and `no_event_in_window` for eclipses, can be wrong. Transit predictions are
not affected. Suggested home: item G, with your approval.
