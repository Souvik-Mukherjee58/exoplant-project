# Eclipse handling (item G): design and test specification

Proposal. Nothing is implemented. Owner direction of 2026-11-24: a separate `eclipse_status`; the four `match_status` values stay;
Monte Carlo and full eccentric-orbit prediction are deferred.

## 1. Scope

| Stage | Content | Gate |
|:--|:--|:--|
| **G1 (Phase 2)** | Read and classify the orbital inputs; make every row that is not excluded visible; no predicted eclipse time | Your approval of this design, then of a diff |
| **G2 (deferred)** | Predicted times, both-solution display with times, exclusion, uncertainty propagation | Inputs and conventions independently checked |

**Tension in the decisions (U7):** "show both solutions" needs two computed times, but full eccentric prediction is deferred. G1 therefore shows
both *conventions* with the raw e and ω and no times. Times for both solutions belong to G2 unless you decide otherwise.

## 2. Facts this rests on

- The current query reads only `pl_orbeccen` (`scripts/build_jwst_labels_from_mast.py:57-61`). No error, limit flag, ω or reference.
- e ≤ 0.1 or missing is treated as circular (`:68`, `:574`). Geometry, computed 2026-11-24: for P = 3 d the eclipse moves by up to 2.3 h at
  e = 0.05 and 4.6 h at e = 0.1.
- For larger e the search range is capped at 0.45 (`:577`). The exact maximum offset is 0.481 at e = 0.9 and 0.489 at e = 0.93.
- The archive's notes say ω conventions differ between publications (planet's orbit or star's reflex orbit, 180° apart) and are not
  standardised. I read this through a search result for the K2 table's column page, not for the composite table itself.
- The combined draft (`.agent/patches/phase2-repair-2026-11-24/0001`, lines 332–338) invents an eclipse time at phase 0.5, and its list
  (`0003`, line 31) shows only `eclipse_in_window`. Both contradict the decisions; the draft must not be used.

## 3. Scientific assumptions

| # | Assumption | If it is wrong | How to check |
|:--|:--|:--|:--|
| S1 | Column names: `pl_orbeccen`, `…err1`, `…err2`, `…lim`, `pl_orblper` and the same suffixes, reference links, `pl_orbsmax` | The query fails, visibly | Archive column page; first live run (owner) |
| S2 | The coding of the limit flags is unknown | Any uninterpretable value is `requires_review` | Archive documentation |
| S3 | e = 0 without an error may be assumed by the authors, not measured | None: it is `requires_review` | Source paper |
| S4 | Values in a composite row can come from different papers | Row is `requires_review` | Reference links |
| S5 | Two-body Keplerian orbit, constant ω | G2 only: precession, TTVs | Not checkable here |
| S6 | e and ω errors are correlated, and the archive gives no correlation | G2 only: any propagated error is approximate | Source posteriors |
| S7 | Light travel across the orbit is about 2a/c (50 s at 0.05 au, 499 s at 0.5 au) | G2 only | Independent review |
| S8 | Time systems are unsupported until validated (P26) | No time comparison is valid | Independent review |

## 4. G1 classification

`eclipse_status` is one value; `eclipse_reasons` lists every reason. The first matching line decides.

| Order | Condition | `eclipse_status` |
|--:|:--|:--|
| 1 | T0 or period missing, non-finite or not positive | `insufficient_parameters` |
| 2 | e missing | `indeterminate` |
| 3 | e < 0, e ≥ 1, or not finite | `requires_review` (invalid value) |
| 4 | e is flagged as a limit, or the flag cannot be interpreted | `requires_review` (limit, not a measurement) |
| 5 | e = 0 and no error | `requires_review` (may be assumed) |
| 6 | e has no usable error | `requires_review` (uncertainty missing) |
| 7 | ω missing, flagged, or without a usable error | `requires_review` (ω not usable) |
| 8 | T0 or period error missing (P31) | `requires_review` (ephemeris uncertainty missing) |
| 9 | References of e, ω, T0, P differ, or one is missing | `requires_review` (mixed or unknown sources) |
| 10 | Time system missing or unsupported | `requires_review` (time system) |
| 11 | ω convention not confirmed for this planet **and** reference | `requires_review` (both conventions shown) |
| 12 | None of the above | `requires_review` (prediction deferred, G2) |

Consequences, on purpose:

- **G1 never outputs a predicted eclipse time, range or exclusion.** Values such as `predicted` or `excluded` are reserved for G2.
- e ≤ 0.1 has no special branch.
- Every (observation, planet) pair of a matched host is "not clearly excluded" in G1, so all of them are listed. The size of that list is unknown.

## 5. `match_status`

| Transit result | With `eclipse_status` (G1) | `match_status` |
|:--|:--|:--|
| Inside the window, all timing inputs validated | any | `transit_in_window` (unreachable while P26 and P27 hold) |
| Anything else | any | `ambiguous` |
| — | needs an excluded or predicted eclipse | `no_event_in_window` and `eclipse_in_window`: **not produced in G1** |

The eclipse field never changes a transit result. While timing is unvalidated (P26), every row is `ambiguous`, so `match_status` gives no
triage and the review order is lost. **U8** asks whether reviewers may see an explicitly unvalidated ordering hint.

## 6. Output and review

New columns: `eclipse_status`, `eclipse_reasons`, `ecc`, `ecc_err_low`, `ecc_err_high`, `ecc_limit_flag`, `omega_deg`, `omega_err_low`,
`omega_err_high`, `omega_limit_flag`, `ecc_reference`, `omega_reference`, `omega_convention`, `omega_convention_source`. Raw strings as received.

`review_labels.py --eclipses`: read-only, minimum change only.

- Lists every row whose `eclipse_status` is not `excluded`; in G1 that means all of them.
- Rows without a time show "no predicted time" and the reasons. Nothing is dropped or sorted by an invented time.
- Where ω is usable and the convention is unconfirmed, it prints both readings: "ω as star's orbit = x°" and "ω as planet's orbit = x°
  (star's = x + 180°)", without times.
- It asks no question and writes nothing. Eclipse rows never join decision groups: approval copies a group's `obs_id`s into the review log.

## 7. Confirming an ω convention (human only)

A protected, human-written file `backend/data/reference/omega_conventions.csv`: `planet_name, omega_reference, convention (star|planet), source
(DOI or URL), location in source (page, section, equation), quoted_text, confirmed_by, date`.

- Valid only for the exact planet **and** reference. A changed reference in the archive voids it.
- The source must be the paper that published ω, or the archive's own documentation about that value.
- A missing field, or an agent as `confirmed_by`, makes it invalid. Agents never write this file.
- Creating the file is a protected-data change and a separate approval (U9).

## 8. Test specification (not written, not run; synthetic data only)

| ID | Test | Must hold |
|:--|:--|:--|
| E01 | e = 0.05 and e = 0.1, all else valid | Never circular; no time |
| E02 | e missing, NaN, empty | `indeterminate`; all time fields blank |
| E03 | e = −0.1, 1.0, infinite | `requires_review` |
| E04 | Limit flag −1, 1, unknown text | `requires_review`; value shown as a limit |
| E05 | e = 0 without and with an error | Without: `requires_review` "may be assumed" |
| E06 | e error missing, one-sided, zero, negative-only | `requires_review` |
| E07 | ω missing; 0°; 359.9°; −10°; flagged | 0° is a value, not "missing" |
| E08 | Each of T0, P, their errors missing | Right status; missing names listed |
| E09 | References differ; one missing | `requires_review` |
| E10 | Time system missing, unknown, known | Missing and unknown: reason present |
| E11 | Convention file: none, matching, other reference, incomplete row, agent name | Only the matching complete row counts |
| E12 | Several conditions at once | First decides the status; all reasons listed |
| E13 | Any input | No output column holds a computed eclipse time, range or epoch |
| E14 | Any input | `match_status` is one of the four; never `eclipse_in_window` or `no_event_in_window` |
| E15 | Same window with every eclipse input varied | Transit result identical |
| E16 | `--eclipses` with rows without times | All listed, reasons shown, order stable |
| E17 | `--eclipses` | Reads only: directory tree and files unchanged; `input()` never called |
| E18 | Decision groups | Contain no eclipse-only row |
| E19 | Both conventions shown | Values differ by exactly 180° modulo 360° |
| E20 | Old candidate CSV without the new columns | Displays with "unknown", no crash |
| E21 | Raw strings | Byte-identical to the cache |
| E22 | Query columns absent from the cache | Clear error, exit 2, nothing written |

G2 tests (geometry against published values, both-solution times, seeded propagation) are to be specified with G2.

## 9. Not claimed

No precision, no predicted time, no exclusion, and no statement that any archive ω follows a given convention.
