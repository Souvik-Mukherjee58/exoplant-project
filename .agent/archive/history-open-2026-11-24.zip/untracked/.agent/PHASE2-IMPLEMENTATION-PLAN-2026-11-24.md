# Phase 2 implementation plan, A–G (for approval)

Nothing is applied. Proposed diffs: `.agent/patches/phase2-repair-2026-11-24/` (five files; all pass `git apply --check`).
They were built and tested only in a scratch clone of `ce4fcff`, with non-loopback sockets blocked (0 attempts).
This replaces `PHASE2-REPAIR-PLAN-2026-11-24.md` where they differ.

## Evidence (scratch clone)

| Run | Result |
|:--|:--|
| `test_mast_label_builder.py` | 183 passed (41 before) |
| `test_review_labels.py` | 16 passed (12 before) |
| Full backend suite, Phase 2 diffs | 424 passed, 1 warning (278 before) |
| Full backend suite, Phase 2 + guard v3.2 | 541 passed, 1 warning |
| Ruff 0.8.4, CI scope and the four scripts | Passed |
| Mutations: break one safeguard, the suite must fail | 48 tried. 45 caught at first; 3 in F exposed weak tests, which were tightened, and then all were caught |
| Guard on this change | `main`: PASS. v3.2: PASS |

Not run: mypy, frontend, anything live. One full run failed with "no space left on device" and was discarded and repeated.

## A. Write-path allow-list

- Each flag has exactly one location in the repository: `reports/.mast_cache`, `reports/jwst_mast_candidates.csv`,
  `reports/jwst_mast_summary.md`. Elsewhere only the system temp directory (and `RUNNER_TEMP` in CI).
- All three are resolved and checked before any fetch, must be separate, and must be of the right kind.
  `write_raw_cache`, `write_candidates_csv` and the summary write check again.
- Tests: 15 forbidden targets × 3 flags, refused before the fetch, with the tree unchanged. They use a **fake repository
  root**, because an earlier draft would have overwritten the real review log if the check ever regressed.
- Limit: if a checkout lives inside the temp directory, sibling folders count as temp.

## B. Dry run

- `--dry-run` is offline and read-only. It cannot be combined with `--force-refresh`.
- No cache, half a cache, no metadata, tampered, or an old cache without the new columns: exit 2 and a clear message.
- Tests compare the whole directory tree before and after, for cache, CSV and summary.

## C. Missing uncertainty

- Missing, zero, NaN or infinite is "missing", per term. The row is always `ambiguous`, never confident and
  never `no_event`. Uncertainty fields stay blank.
- New column `uncertainty_status`, note `ephemeris_uncertainty_missing_<term>`, a count in the summary, and
  "UNVERIFIED TIMING" in the reviewer.
- Cost: every window of an affected host yields a row. The number is unknown without real data.

## D. Timing: margin removed, conversion not implemented

Removing 0.25 h alone would be unsafe: the two time systems differ by up to about 9.5 minutes, so rows near a window edge
would become falsely confident. The diff therefore does two things:

- **Removes** the margin and `--margin-hours`.
- **Adds** a 600 s bound, the documented sum of light travel (514.0 s), TDB−UTC (69.2 s) and JWST's distance (6.0 s), rounded
  up. It is a worst case, not a chosen tolerance, and a test ties it to its parts.

Unknown or missing `pl_tranmid_systemref` is `ambiguous`. Raw times and uncertainties are unchanged. Rows whose status the
old margin would have changed are marked and counted. No conversion is claimed anywhere.

**Needed before a conversion (D2, not in the diff):**

| Input | Status | How to establish it |
|:--|:--|:--|
| MAST `t_min`/`t_max` scale | MAST documents MJD; no scale found | Owner compares sample rows with FITS headers at H1 |
| Archive time system per planet | Column documented; values not seen | Read from the first real cache; list every distinct value |
| Target coordinates and epoch | Position fetched; its epoch is not | Archive documentation |
| JWST position | Not fetched | JPL Horizons or the FITS headers; otherwise keep the 6 s bound |
| Leap seconds | Bundled with astropy | Pin astropy explicitly |

Which values count as "known" time systems (BJD, HJD or JD, with TDB, TT or UTC) is my assumption. Anything else fails safe.

**A decision for you:** does a worst-case bound meet "use the timing requirements in PLAN.md"? PLAN.md says to convert. Until
D2 the bound is the conservative substitute, and it makes slightly more rows confident than 900 s did.

## E. Identity, assignment and provenance

| Check | Behaviour |
|:--|:--|
| `obs_id` missing | Dropped and counted |
| Same `obs_id`, identical rows | Merged and counted |
| Same `obs_id`, different content | Run aborts, nothing written |
| `calib_level` < 0 | Dropped and counted (the meaning of −1 is unverified) |
| Position disagrees with the host, or is missing | `ambiguous` |
| Name suffix | Only a letter of a known planet of that host |
| Name gives another planet | `ambiguous` |
| Several planets with an event in one window | Noted |
| T0 and period from different papers | Noted, both references kept |
| Provenance | Each row has its MAST row hash and both cache hashes; `check_mast_cache.py` verifies them against the cache |
| Completeness | New `scripts/check_mast_completeness.py`, owner-run and live: runs PLAN.md's per-host query and fails on anything the bulk table lacks. Only `--all-hosts` supports the full statement |

**Not guaranteed:** that a timing match is the program's target (human review decides); that a nearby companion "B" within the
matching radius is not read as planet "b"; that hashes stop a deliberate rewrite of data and hashes together. Proper motion
is not applied, so fast stars may become `ambiguous`. `pl_tranmid_reflink`, `pl_orbper_reflink` and `pl_tranmid_systemref`
come from the archive's documentation; the query has not been run, and a wrong name would make the fetch fail loudly.
Whether real MAST data has conflicting duplicate `obs_id`s is unknown; if so, the run stops and you decide.

## F. `check_mast_cache.py`

Fails on: different row counts either way, different id sets, missing or repeated ids, changed title or times, every copy of a
repeated id, and candidates from another cache or changed rows. The test that asserted the opposite is replaced, as approved.

## G. Eclipses, and the minimum reviewer change

- New columns: epoch, predicted time, uncertainty, and for eccentric orbits a start and end instead of a time.
- `review_labels.py`: shows these and the uncertainty flag, and adds `--eclipses`, a **read-only list**.
- Eclipse rows never enter decision groups. Approval copies the group's `obs_id`s into the review log, so merging them would
  record eclipse observations as approved transmission. A test covers this.
- No other Phase 3 change. Phase 3 stays unticked.

## Files

`scripts/build_jwst_labels_from_mast.py`, `scripts/check_mast_cache.py`, `scripts/check_mast_completeness.py` (new),
`scripts/review_labels.py`, two test files, `fixture_nasa_ephemerides.csv` (three synthetic columns), ADR 0006.
None is protected. ADR 0006's header still says "reviewed by the owner"; I left it, please confirm or correct it.

## Order once approved

A, B, C, F, G, E, D. One commit each, tests first, full suite after each. The diffs are cumulative, so I will split them by
item. Phase 2 stays unticked until the owner's H1.
