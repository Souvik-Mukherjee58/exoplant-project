# Phase 2 repair plan (proposal, 2026-11-24)

Nothing here is implemented. No source, test, dataset, report or cache file has been changed.
Base: `1dff28a` as it stands on `main` @ `ce4fcff`. "Reproduced" means an offline, in-memory probe.

## Order of work

| Order | Item | Your # | Why here | Files |
|:--|:--|:--|:--|:--|
| 1 | A. Safe write paths | 2 | Can overwrite human-owned data | builder, tests |
| 2 | B. Dry-run without network or writes, and its tests | 3, 5 | Must be safe before anyone runs it | builder, tests |
| 3 | C. Missing uncertainty | 1 | Silently hides events | builder, tests |
| 4 | D. Time-scale conversion | margin | Changes every match | builder, `data_ingestion.py`, requirements-dev, ADR, tests |
| 5 | E. Host/planet assignment and provenance | bulk query | Changes which planet a row is about | builder, tests, ADR |
| 6 | F. Strict row count | 6 | Verifies the cache that A–E produce | `check_mast_cache.py`, tests |
| 7 | G. Predicted eclipse times | 4 | Output and display only | builder, `review_labels.py`, tests |

One commit per item, tests first (each new test must fail before the fix), full backend suite after each.
Owner checkpoint H1 only after all of them.

## A. Safe write paths

**Today (reproduced):** `--cache-dir backend/data/reference` reaches the fetch step unchecked.
`--output` and `--summary` refuse only `backend/data/reference/`; `assert_safe_output` accepts
`reports/LABEL_REVIEW.md`, `reports/CYCLE4_SOURCE.md`, `docs/assets/…` and `scripts/guard_changes.py`.

**Change:** replace the deny-list with an allow-list, on resolved paths (symlinks, `..`, case):

- Inside the repository: the cache only in `reports/.mast_cache/`; the output only
  `reports/jwst_mast_candidates.csv`; the summary only `reports/jwst_mast_summary.md`.
- Outside the repository: allowed (tests and the CI job use temporary directories).
- Output and summary must differ. Check all three in `main` before any fetch, and the cache directory
  again inside `write_raw_cache`.

**Tests:** each protected path refused for each flag; `..`, a case variant, and a symlink or junction
refused; refusal happens before the (patched) fetch; `tmp_path` still allowed.

## B. Dry-run

**Today (reproduced):** with no cache, `--dry-run` calls MAST, then writes the cache.

**Change:** `--dry-run` means no network and no writes. It implies `--offline`, rejects `--force-refresh`
(argparse error), and exits 2 with a clear message when the cache is missing. No directory is created.

**Tests:** missing cache gives exit 2 with zero fetch calls and no files; with a cache, neither the CSV nor
the **summary** exists afterwards and the cache bytes and directory listing are unchanged;
`--dry-run --force-refresh` is rejected.

## C. Missing ephemeris uncertainty

**Today (reproduced):** either σ missing is set to 0. A near miss becomes `no_event_in_window`, the row is
dropped, and the emitted host-level row has an empty note. The stale check cannot fire.

**Change:**

- If σ(T0) or σ(P) is missing, non-finite or not positive, the result is always `ambiguous`, note
  `ephemeris_uncertainty_missing` (naming the missing term). Never `no_event`, never confident.
- `timing_uncertainty_hours` is blank, never a number computed from an assumed zero.
- `build_candidates` keeps these rows, so reviewers see them.

**Cost:** more `ambiguous` rows. How many is unknown without real data; the summary must count them.

**Tests:** both missing, only σ(T0), only σ(P), zero, NaN, each for a hit, a near miss and a far miss; the
note reaches the CSV; known-σ results are unchanged.

## D. Time-scale conversion (replaces the 15-minute margin)

Two different things are called "BJD to MJD":

1. **Epoch shift:** MJD = JD − 2400000.5. Exact, and already done (`to_mjd`).
2. **Time scale and place:** `pl_tranmid` is barycentric TDB; MAST times are taken as UTC at the telescope.
   This is what the 0.25 h margin covers today.

**Proposed conversion**, per observation, in the direction that needs no iteration:

```
t_TDB  = UTC -> TAI -> TT -> TDB                      (astropy, bundled leap seconds)
t_BJD  = t_TDB + (r_observer · n_target) / c          (light travel to the barycentre)
```

- Convert `t_min` and `t_max` to BJD_TDB and match in BJD_TDB. `assign_planet_event` stays a pure function.
- Predicted events are written as `*_bjd_tdb` and as `*_mjd_utc` (inverse, fixed-point iteration).
- Raw `t_min`/`t_max` stay byte-for-byte as received.
- Offline: built-in ephemeris, `iers.conf.auto_download = False`. Add `astropy` explicitly to
  `requirements-dev.txt` (today it arrives only through `astroquery`).

**Measured offline (astropy 8.0.2, dates 2022–2026):** BJD_TDB − MJD_UTC runs from −7.34 to +9.47 min,
depending on sky position and date; round-trip error is 20 µs.

**How exact this is.** The calculation is, but three inputs bound it:

| Input | Bound | Handling |
|:--|:--|:--|
| Geocentre used instead of JWST | about 6 s (1.8 million km) | fixed 10 s tolerance, stated in the output |
| Archive time system differs by planet | up to about 9.5 min if not BJD_TDB | fetch `pl_tranmid_systemref`; convert known systems explicitly; unknown or missing gives `ambiguous` with a note, never a guess |
| MAST `t_min` scale | MAST documents MJD; I found no statement of the scale | H1 check: compare sample rows with the FITS headers before trusting it |

**The margin:** PLAN.md defines no margin, only propagated uncertainty. Proposed: `--ttv-margin-hours` default
0, plus the fixed 10 s. To lose no caution, rows whose status would change under the old 0.25 h margin get
the note `status_depends_on_15min_margin`. Removing the margin makes some rows *more* confident, so this
is an owner decision.

**Tests:** synthetic values against independently computed references (ecliptic plane and pole, both signs);
round-trip; leap-second scale; a window edge that flips with the sign of the correction; unknown time system
is ambiguous; no network (sockets blocked).

## E. Bulk query: assignment and provenance

**What can and cannot be guaranteed.** A timing match shows that a window is *consistent with* a planet's
ephemeris. It cannot prove intent, and a SHA-256 stored beside the file detects accidental change, not a
deliberate rewrite of both. So "guaranteed" would be wrong. The honest chain is: raw row → unique host →
planet by timing → live re-check → human approval.

| Link | Today | Proposed |
|:--|:--|:--|
| Completeness | One `timeseries` query; not proven to cover PLAN.md's `spectrum` | Owner-run H1 check: for a fixed host list, run PLAN.md's per-host query for both types and report every time-series-mode row the bulk query lacks. Any miss blocks H1 |
| Executed observations | `calib_level` not read; whether planned observations appear is unverified | Keep `calib_level`; reject non-executed rows, with a count |
| Row identity | Missing `obs_id` rows collapse to one; conflicting duplicates dropped (reproduced) | Missing `obs_id`: rejected and counted. Identical duplicates: merged. Conflicting duplicates: run fails |
| Host | A name match wins without a coordinate check, even 100° away (reproduced) | Name **and** coordinates must agree, with proper motion applied. Disagreement or missing coordinates: `ambiguous` |
| Companion stars | "SYN-9 B" is read as planet b (reproduced) | Strip a planet letter only if that planet exists for the host **and** coordinates agree; otherwise `ambiguous` |
| Planet | Each planet tested separately | Same, plus a note when more than one planet has an event in the window |
| Ephemeris | Composite table; T0 and P may come from different papers | Store `pl_tranmid_reflink`, `pl_orbper_reflink` and the time system; different references give a note |
| Row provenance | Hash only in the summary | Each row carries both cache SHA-256 values and a hash of its raw MAST row; `review_labels.py --summary` rejects a CSV whose hashes do not match the cache |
| Raw bytes | astropy ECSV of the parsed table | Keep (PLAN.md asks for `.ecsv`), and describe it as "serialised table", not "raw response" |

**Tests:** one per row above that can be tested offline, with synthetic data.

## F. Strict row count in `check_mast_cache.py`

**Change:** FAIL when the live and cached row counts differ in either direction, when the `obs_id` sets differ, or
when either side has duplicate `obs_id`s. The message says whether new data is the likely cause and that
`--force-refresh` is the remedy.

**Test change to approve:** `test_cache_check_only_warns_on_new_live_rows` asserts the opposite of PLAN.md. It
becomes `…fails_on_new_live_rows`, with at least as many assertions. New: equal counts with different ids fail.

**Cost:** a program that takes new data between fetch and check fails until refreshed. That is what PLAN.md asks.

## G. Predicted eclipse times

**Change:** add `eclipse_epoch`, `predicted_mid_eclipse_*` and `eclipse_uncertainty_hours`. Transit columns keep their
meaning, and `timing_uncertainty_hours` becomes transit-only. For eccentric orbits without a predictable
time, leave the time blank and give `eclipse_window_start`/`_end` instead.

`review_labels.py` shows only `transit_in_window` and `ambiguous` rows and prints only mid-transit. Proposed: print
the eclipse columns on `ambiguous` rows. `eclipse_in_window` rows stay in the CSV and the summary, because
PLAN.md's review list does not include them.

**Tests:** circular and eccentric cases, values in the CSV, display in the review prompt.

## Done when

- Every new test fails before its fix and passes after; the full backend suite, ruff and mypy pass; counts recorded.
- The tests run with sockets blocked and make 0 connection attempts.
- ADR 0006 is revised to match. `git diff` shows no change under `backend/data/reference/` or to any protected path.
- Phase 2 still stays unticked until the owner completes H1.

## Owner decisions

1. Approve A–G, or a subset, in this order?
2. D: margin default 0 (PLAN.md) with the sensitivity note, or keep 0.25 h as a named TTV allowance?
3. E: keep the bulk query if the H1 completeness check passes, or return to PLAN.md's per-host queries?
4. F: approve inverting that one test?
5. G: should `eclipse_in_window` rows also appear in the review tool?
6. `review_labels.py` is a Phase 3 file. May E and G touch it?

## Corrections to `.agent/PHASE2-VERIFICATION-2026-11-23.md` (left unchanged)

- It says dead proxy settings would make any live call fail. Only proxy-aware clients are stopped that way. Re-run
  with non-loopback sockets blocked: same results, 0 connection attempts.
- It marks the raw cache "Met" and the row-count change unrecorded. The cache is a serialised table, and the row-count
  change is documented in the script's docstring.
- It limits the path gap to `--cache-dir`. `--output` and `--summary` are affected too.
- It missed the host-match, `obs_id`, time-system and row-provenance gaps in E.
