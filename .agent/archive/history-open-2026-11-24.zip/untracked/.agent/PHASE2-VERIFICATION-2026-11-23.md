# Phase 2 verification (read-only), 2026-11-23

Scope: commit `1dff28a` ("phase 2: real MAST label candidates with ephemeris-based planet assignment")
against `.agent/PLAN.md` Phase 2. The Phase 2 files are unchanged since `1dff28a` (checked with `git log`).

Method:

- Read `scripts/build_jwst_labels_from_mast.py`, `scripts/check_mast_cache.py`,
  `.github/workflows/mast-live-check.yml`, `backend/app/services/data_ingestion.py`,
  `backend/tests/test_mast_label_builder.py` and ADR 0006.
- Ran the tests with HTTP(S) proxies pointed at a dead local port, so any accidental live call would fail.

No live MAST or NASA call was made, no dataset or artifact was generated, no source file was edited,
and nothing was committed. Verdict: **not marked complete.** The core requirements are implemented and
tested offline, but there are documented deviations, four gaps (P2-1 to P2-4 below) and nothing checked live.

## Test results

All runs were on the real working tree at `main` @ `ce4fcff`, with network blocked as above.

| Command (from `backend/`) | Result |
|:--|:--|
| `venv/Scripts/python.exe -m pytest -q -p no:cacheprovider tests/test_mast_label_builder.py` | 41 passed |
| `… tests/test_ingestion.py tests/test_data_integrity.py tests/test_review_labels.py tests/test_guard.py` | 38 passed |
| `venv/Scripts/python.exe -m pytest -q -p no:cacheprovider` (full backend) | 278 passed, 1 warning |
| `ruff 0.8.4 check` on both Phase 2 scripts and their test file | All checks passed |

Not run: mypy, frontend checks, `check_mast_cache.py` (it needs live MAST), and the script itself.

After the runs, `reports/.mast_cache/`, `reports/jwst_mast_candidates.csv` and `reports/jwst_mast_summary.md`
do not exist, and `git status` was unchanged.

## Requirement matrix (PLAN.md Phase 2)

| # | Requirement | Status | Evidence / note |
|:--|:--|:--|:--|
| 1 | `query_criteria(obs_collection="JWST", target_name=<host variants>, dataproduct_type=["timeseries","spectrum"])` per host | **Deviation (documented)** | One bulk query `{"obs_collection":"JWST","dataproduct_type":"timeseries"}` with host matching done locally (`MAST_QUERY`, `match_host`). ADR 0006 justifies it. Its claim that every JWST transit/eclipse product is `timeseries` was not checked here. |
| 2 | Rate limit, retries with backoff | Met | `with_retries`: 4 attempts, exponential backoff. A single bulk query makes rate limiting largely moot. |
| 3 | Raw cache `.ecsv` + `.meta.json` (fetched_at UTC, astroquery version, query, row count, SHA-256); SHA verified on read | Met | `write_raw_cache` / `read_raw_cache`; tests `test_cache_roundtrip_and_sha256`, `test_tampered_cache_raises`, `test_meta_json_records_sha_and_query`. The cache is the astropy ECSV serialisation of the returned table. |
| 4 | Time-series spectroscopy modes only; keep the listed columns | Met | `is_time_series_spectroscopy` (NIRISS SOSS, NIRSpec BOTS gratings and PRISM, NIRCam grism, MIRI P750L); `mast_table_to_frame` keeps the eight columns plus `s_ra`/`s_dec`. |
| 5 | `pl_tranmid` (+ errors) and `pl_orbper` in the TAP query in data_ingestion.py | Met | `backend/app/services/data_ingestion.py` (+ period errors). The script also runs its own TAP query (`EPHEMERIS_ADQL`). |
| 6 | Convert BJD/JD to MJD | **Partial (documented)** | `to_mjd` does JD→MJD. The BJD_TDB vs MJD offset (≤ ~10 min) is absorbed by `--margin-hours` 0.25 h rather than converted (module docstring and ADR 0006). |
| 7 | Mid-transit inside the window with propagated ephemeris uncertainty | Met, with gap P2-1 | `check_event`: σ(n) = sqrt(σT0² + n²σP²), ±3σ + margin. |
| 8 | Output `assigned_planet, transit_epoch, predicted_mid_transit, timing_uncertainty_hours, match_status` ∈ 4 values | Met, with gap P2-4 | `CANDIDATE_FIELDS`, `MATCH_STATUSES`. |
| 9 | `likely_type` from title keywords AND match_status | Met | `combine_likely_type` reports disagreements as `conflict` rather than resolving them. |
| 10 | Write `reports/jwst_mast_candidates.csv` and `reports/jwst_mast_summary.md`; never write to `backend/data/reference/` | Met for outputs, gap P2-2 | `assert_safe_output` guards the output and summary paths, but not `--cache-dir`. |
| 11 | Flags `--force-refresh`, `--hosts`, `--dry-run` | Met, caveat P2-3 | Also `--offline`. |
| 12 | SYNTHETIC `.ecsv` fixture tests: filtering, transit/eclipse/no-event, SHA-256, obs_title unmodified | Met | 41 tests; the fixtures are watermarked (`test_fixture_files_are_marked_synthetic`). |
| 13 | `check_mast_cache.py`: re-query 3 random proposals; FAIL if obs_title, t_min or row count differ; manual CI job | **Mostly met, deviation P2-5** | Fails on SHA mismatch, whole-number MJDs, a missing cached obs_id, or a changed title/t_min/t_max. New live rows only produce a warning, so row count is not compared strictly. `mast-live-check.yml` is `workflow_dispatch`. |
| 14 | Never fabricate output | Met | No cache or candidate output is committed or present. |

## Findings (no fixes made: source edits were out of scope)

- **P2-1 (medium): a missing ephemeris uncertainty can hide an event.**
  - When `pl_tranmiderr*` or `pl_orbpererr*` is missing, σ is set to 0. The stale-ephemeris check can then never fire.
  - Only `*_in_window` results are downgraded to `ambiguous`; a near miss is still reported as `no_event_in_window`.
  - Reproduced offline: a transit predicted 2.4 h before the window is `no_event_in_window` with the errors missing, and `ambiguous` with σT0 = 0.05 d.
  - `build_candidates` drops per-planet `no_event` rows, so the `ephemeris_uncertainty_missing` note never reaches the reviewer.
- **P2-2 (low):** `--cache-dir` is not checked by `assert_safe_output`. `--cache-dir backend/data/reference` would write the cache there.
- **P2-3 (low):** `--dry-run` writes no candidates or summary. But without a cache it still queries MAST and NASA live and writes the cache. For a run with no network, use `--offline --dry-run`.
- **P2-4 (low):** `eclipse_in_window` rows carry no predicted eclipse time (`predicted_mid_transit` is empty), so the reviewer cannot see when the event was expected.
- **P2-5 (info):** `check_mast_cache.py` does not FAIL on extra live rows (the PLAN text says row count). This is reasonable, since MAST gains observations over time, but it isn't recorded as a deviation.
- **P2-6 (low):** `test_dry_run_writes_nothing` asserts only that the candidates CSV is absent, not the summary.
- **P2-7 (info):** the live figures in the commit message (4,187 MAST rows, 4,830 planets, check_mast_cache PASS on 3 proposals) were not reproduced; no live calls were made. ADR 0006's "reviewed by the owner" cannot be verified from the repository.

## What completing Phase 2 would need

1. Owner decision on P2-1 to P2-4 (fix in a later, approved change, or accept and document).
2. Owner decision to accept the deviations in rows 1, 6 and 13.
3. Then checkpoint H1, which only the owner can run (live):
   `python scripts/build_jwst_labels_from_mast.py --force-refresh` and `python scripts/check_mast_cache.py`.
